Projekt zaliczeniowy na kurs Równania różniczkowe w technice (3 semestr).
Temat: Newtonowski model gwiazdy.