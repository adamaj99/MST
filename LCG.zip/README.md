Sprawozdanie na kurs Symulacje komputerowe (4 semestr). Projekt generatora LCG dla bardzo dużych liczb zmiennoprzecinkowych.

Report for Computer simulations course (4th semester). LCG generator for very large floats.