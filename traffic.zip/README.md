Sprawozdanie na przedmiot Symulacje komputerowe (4 semestr). Symulacja ruchu drogowego w pygame.

Report for Computer Simulations course (4th semester). Traffic jam simulation in pygame.