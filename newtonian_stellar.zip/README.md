Projekt zaliczeniowy na kurs Równania różniczkowe w technice (3 semestr).
Temat: Newtonowski model gwiazdy i równanie Lane-Emdena.

Final project for Differential Equations in Technology course (3rd semester).
Topic: Newtonian stellar model and Lane-Emden equation.