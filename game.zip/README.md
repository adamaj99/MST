Gra wykonana w ramach projektu zaliczeniowego na kurs Programowanie w drugim semestrze, inspirowana grą arakdową Space Invaders.
Napisana w Visual Studio Code.

This game was made as a final project for programming class in my second semester and is inspired by arcade game Space Invaders.
Written in Visual Studio Code.