This game was made as a final project for programming class in my second semester and is inspired by Arcade game Space Invaders.
Written in Visual Studio Code.